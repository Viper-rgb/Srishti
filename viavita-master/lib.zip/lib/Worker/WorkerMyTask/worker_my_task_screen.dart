// // import 'package:flutter/material.dart';
// // import 'package:via_vita_mobile_app/CommonScreens/colors.dart';
// // import 'package:via_vita_mobile_app/CommonScreens/images.dart';



// // class Task {
// //   final String title;
// //   final String description;
// //   final String price;
// //   final TaskStatus status;

// //   Task({
// //     required this.title,
// //     required this.description,
// //     required this.price,
// //     required this.status,
// //   });
// // }

// // enum TaskStatus { AcceptedTask, InProgress, Completed }

// // class WorkerMyTaskScreen extends StatefulWidget {
// //   @override
// //   _WorkerMyTaskScreenState createState() => _WorkerMyTaskScreenState();
// // }

// // class _WorkerMyTaskScreenState extends State<WorkerMyTaskScreen> {
// //   TaskStatus _selectedStatus = TaskStatus.InProgress;

// //   final List<Task> allTasks = [
// //     Task(
// //       title: 'Electrical Work',
// //       description: 'Rewire living room, install ceiling fans and light fixtures.',
// //       price: '₹25,000/-',
// //       status: TaskStatus.InProgress,
// //     ),
// //     Task(
// //       title: 'Gardening',
// //       description: 'Plant new shrubs, trim hedges, and prepare garden soil.',
// //       price: '₹5,000/-',
// //       status: TaskStatus.InProgress,
// //     ),
// //     Task(
// //       title: 'House Cleaning',
// //       description: 'Deep clean 3BHK home including kitchen, bathrooms, and living area.',
// //       price: '₹2,500/-',
// //       status: TaskStatus.Completed,
// //     ),
// //     Task(
// //       title: 'Plumbing Repair',
// //       description: 'Fix leaky faucet in kitchen and unclog bathroom drain.',
// //       price: '₹1,500/-',
// //       status: TaskStatus.Completed,
// //     ),
   
// //   ];

// //   List<Task> get _filteredTasks {
// //     return allTasks.where((task) => task.status == _selectedStatus).toList();
// //   }

// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       backgroundColor: Colors.white,
// //       appBar: PreferredSize(
// //         preferredSize: const Size.fromHeight(60.0), // Custom height for the AppBar
// //         child: AppBar(
// //           backgroundColor: Colors.white,
// //           elevation: 0,
// //           leading: IconButton(
// //             icon: const Icon(Icons.arrow_back_ios, color: Colors.black, size: 20),
// //             onPressed: () {
// //               Navigator.of(context).pop(); // Go back
// //             },
// //           ),
// //           title: const Text(
// //             'My Tasks',
// //             style: TextStyle(
// //               color: Colors.black,
// //               fontSize: 17,
// //               fontWeight: FontWeight.w500,
// //             ),
// //           ),
        
        
// //         ),
// //       ),
// //       body: Column(
// //         children: [
// //           // Segmented Control for Task Status
// //           Padding(
// //             padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
// //             child: Row(
// //               children: [
// //                 _buildStatusButton(TaskStatus.AcceptedTask, 'Accepted Task'),
// //                 _buildStatusButton(TaskStatus.InProgress, 'In Progress'),
// //                 const SizedBox(width: 10),
// //                 _buildStatusButton(TaskStatus.Completed, 'Completed'),
             
// //               ],
// //             ),
// //           ),
// //           const SizedBox(height: 20),
// //           // List of Task Cards
// //           Expanded(
// //             child: _filteredTasks.isEmpty
// //                 ? Center(
// //                     child: Text(
// //                       'No ${_selectedStatus.toString().split('.').last} tasks.',
// //                       style: TextStyle(fontSize: 16, color: Colors.grey[600]),
// //                     ),
// //                   )
// //                 : ListView.builder(
// //                     padding: const EdgeInsets.symmetric(horizontal: 16.0),
// //                     itemCount: _filteredTasks.length,
// //                     itemBuilder: (context, index) {
// //                       final task = _filteredTasks[index];
// //                       return _buildTaskCard(task);
// //                     },
// //                   ),
// //           ),
// //         ],
// //       ),
// //     );
// //   }

// //   Widget _buildStatusButton(TaskStatus status, String label) {
// //     bool isSelected = _selectedStatus == status;
// //     return Expanded(
// //       child: GestureDetector(
// //         onTap: () {
// //           setState(() {
// //             _selectedStatus = status;
// //           });
// //         },
// //         child: Container(
// //           padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
// //           decoration: BoxDecoration(
// //             color: isSelected ? colors.task_progress_color : Colors.white, // Light red/orange background
// //             borderRadius: BorderRadius.circular(8),
            
// //           ),
// //           child: Center(
// //             child: Text(
// //               label,
// //               style: TextStyle(
// //                 color: isSelected ? colors.progress_bar_text_color : colors.task_text_color,
// //                 fontWeight: isSelected ? FontWeight.w500 : FontWeight.normal,
// //                 fontSize: 12,
// //               ),
// //               textAlign: TextAlign.center,
// //             ),
// //           ),
// //         ),
// //       ),
// //     );
// //   }

// //   Widget _buildTaskCard(Task task) {
// //     return InkWell(
// //       onTap: () {
// //         //  Navigator.push(context, MaterialPageRoute(builder: (context)=>PaintingDetailsScreen()));
// //       },
// //       child: Container(
// //         margin: const EdgeInsets.only(bottom: 15),
// //         padding: const EdgeInsets.all(16),
// //         decoration: BoxDecoration(
// //           color: colors.task_list_color,
// //           borderRadius: BorderRadius.circular(12),
// //           boxShadow: [
// //             BoxShadow(
// //               color: Colors.grey.withOpacity(0.1),
// //               spreadRadius: 2,
// //               blurRadius: 5,
// //               offset: const Offset(0, 3), // changes position of shadow
// //             ),
// //           ],
// //         ),
// //         child: Column(
// //           crossAxisAlignment: CrossAxisAlignment.start,
// //           children: [
// //             Row(
// //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //               children: [
// //                 Text(
// //                   task.title,
// //                   style: const TextStyle(
// //                     fontSize: 15,
// //                     fontWeight: FontWeight.w500,
// //                     color: colors.task_text_color
// //                   ),
// //                 ),
// //                 Text(
// //                   task.price,
// //                   style: const TextStyle(
// //                     fontSize: 13,
// //                     fontWeight: FontWeight.w400,
// //                     color: colors.task_text_color// Price color
// //                   ),
// //                 ),
// //               ],
// //             ),
// //             SizedBox(height: 10),
// //             Row(
// //               children: [
// //                 const SizedBox(height: 8),
// //                 Image.asset(Appicons.loaction_icon, scale: 5, color: colors.task_text_color), const SizedBox(width: 8),
// //                 Text(
// //                   'Location',
// //                   style: const TextStyle(
// //                     fontSize: 13,
// //                     color: colors.task_text_color,
// //                   ),
// //                 ),
// //               ],
// //             ),
// //             SizedBox(height: 10),
// //             Divider(
// //               color: colors.divider_color
// //             ),
// //            SizedBox(height: 10),
// //             Row(
// //               children: [
// //                 Expanded(
// //                   child: Text(
// //                     task.description,
// //                     style: TextStyle(
// //                       fontSize: 13,
// //                       color: colors.task_text_color,
// //                       fontWeight: FontWeight.w500
// //                     ),
// //                   ),
// //                 ),
// //                 const SizedBox(width: 10),
// //                 Icon(
// //                   Icons.arrow_forward_ios,
// //                   color: colors.task_text_color,
// //                   size: 18,
// //                 ),
// //               ],
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:via_vita_mobile_app/CommonScreens/colors.dart';
// import 'package:via_vita_mobile_app/CommonScreens/images.dart';
// import 'package:via_vita_mobile_app/Providers/accepted_task_provider.dart';
// import 'package:via_vita_mobile_app/Providers/worker_profile_provider.dart';
// import 'package:via_vita_mobile_app/DataModels/accepted_task_model.dart';
// import 'package:via_vita_mobile_app/Worker/Detail/accepttask_worker_detail_screen.dart';

// class WorkerMyTaskScreen extends StatefulWidget {
//   @override
//   _WorkerMyTaskScreenState createState() => _WorkerMyTaskScreenState();
// }

// class _WorkerMyTaskScreenState extends State<WorkerMyTaskScreen> {
//   int _selectedTabIndex = 0;

//   @override
//   void initState() {
//     super.initState();
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       final worker = Provider.of<WorkerProfileProvider>(context, listen: false);
//       Provider.of<AcceptedTaskProvider>(context, listen: false)
//           .fetchAcceptedTasks(worker.profile?.workerId ?? "");
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         elevation: 0,
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back_ios, color: Colors.black, size: 20),
//           onPressed: () => Navigator.pop(context),
//         ),
//         title: const Text(
//           'Tasks',
//           style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w600),
//         ),
//       ),
//       body: Consumer<AcceptedTaskProvider>(
//         builder: (context, provider, child) {
//           return Column(
//             children: [
//               // --- Custom Tabs Section ---
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     _buildTabItem(0, "Accepted Task"),
//                     _buildTabItem(1, "In Progress"),
//                     _buildTabItem(2, "Completed"),
//                   ],
//                 ),
//               ),

//               const SizedBox(height: 10),

//               // --- Task List Section ---
//               Expanded(
//                 child: provider.isLoading
//                     ? const Center(child: CircularProgressIndicator(color: Color(0xFFA13C2B)))
//                     : _selectedTabIndex != 0 
//                         ? const Center(child: Text("No tasks in this section"))
//                         : provider.tasks.isEmpty
//                             ? const Center(child: Text("No accepted tasks available"))
//                             : ListView.builder(
//                                 padding: const EdgeInsets.symmetric(horizontal: 16),
//                                 itemCount: provider.tasks.length,
//                                 itemBuilder: (context, index) => _buildTaskCard(provider.tasks[index]),
//                               ),
//               ),
//             ],
//           );
//         },
//       ),
//     );
//   }

//   // Tab Button Widget
//   Widget _buildTabItem(int index, String title) {
//     bool isSelected = _selectedTabIndex == index;
//     return GestureDetector(
//       onTap: () => setState(() => _selectedTabIndex = index),
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//         decoration: BoxDecoration(
//           color: isSelected ? const Color(0xFFFFF1F0) : Colors.transparent,
//           borderRadius: BorderRadius.circular(10),
//         ),
//         child: Text(
//           title,
//           style: TextStyle(
//             color: isSelected ? const Color(0xFFA13C2B) : Colors.grey,
//             fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
//             fontSize: 13,
//           ),
//         ),
//       ),
//     );
//   }

//   // Task Card Widget (Matches Image)
//   Widget _buildTaskCard(AcceptedTaskModel task) {
//     return GestureDetector(
//       onTap: () {
//         Navigator.push(context, MaterialPageRoute(builder: (context) => ProjectDetailsScreen(task: task))); 
//       },
//       child: Container(
//         margin: const EdgeInsets.only(bottom: 16),
//         padding: const EdgeInsets.all(20),
//         decoration: BoxDecoration(
//           color: colors.container_color,
//           borderRadius: BorderRadius.circular(15),
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             // Category and Budget Row
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text(
//                   task.categoryName ?? "Category",
//                   style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Color(0xFF535E73)),
//                 ),
//                 Text(
//                   "₹${task.budget}/-",
//                   style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Color(0xFF535E73)),
//                 ),
//               ],
//             ),
//             const SizedBox(height: 10),
      
//             // Location Row
//             Row(
//               children: [
//                 Image.asset(Appicons.loaction_icon, scale: 5, color: Colors.grey),
//                 const SizedBox(width: 8),
//                 Expanded(
//                   child: Text(
//                     task.location ?? "123 Street, TVM",
//                     style: const TextStyle(color: Colors.grey, fontSize: 13),
//                   ),
//                 ),
//               ],
//             ),
            
//             const Padding(
//               padding: EdgeInsets.symmetric(vertical: 15.0),
//               child: Divider(color: Color(0xFFF0F0F0), thickness: 1.5),
//             ),
      
//             // Description and Arrow Row
//             Row(
//               children: [
//                 Expanded(
//                   child: Text(
//                     task.taskDescription ?? "No description available",
//                     maxLines: 2,
//                     overflow: TextOverflow.ellipsis,
//                     style: const TextStyle(color: Color(0xFF7D8797), fontSize: 13, height: 1.4),
//                   ),
//                 ),
//                 const SizedBox(width: 10),
//                 const Icon(Icons.arrow_forward_ios, size: 16, color: Color(0xFF535E73)),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:via_vita_mobile_app/CommonScreens/colors.dart';
import 'package:via_vita_mobile_app/CommonScreens/images.dart';

// Import all 3 Providers
import 'package:via_vita_mobile_app/Providers/accepted_task_provider.dart';
import 'package:via_vita_mobile_app/Providers/complete_task_provider.dart';
import 'package:via_vita_mobile_app/Providers/in_progress_task_provider.dart';


import 'package:via_vita_mobile_app/Providers/worker_profile_provider.dart';
import 'package:via_vita_mobile_app/Worker/Detail/accepttask_worker_detail_screen.dart';
import 'package:via_vita_mobile_app/Worker/Detail/completed_task_detailscreen.dart';
import 'package:via_vita_mobile_app/Worker/Detail/inprogresstask_detail_screen.dart';

class WorkerMyTaskScreen extends StatefulWidget {
  @override
  _WorkerMyTaskScreenState createState() => _WorkerMyTaskScreenState();
}

class _WorkerMyTaskScreenState extends State<WorkerMyTaskScreen> {
  int _selectedTabIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final workerId = Provider.of<WorkerProfileProvider>(context, listen: false).profile?.workerId ?? "";
      
      // Fetch data for all three categories
      Provider.of<AcceptedTaskProvider>(context, listen: false).fetchAcceptedTasks(workerId);
      Provider.of<InProgressTaskProvider>(context, listen: false).fetchInProgressTasks(workerId);
      Provider.of<CompleteTaskProvider>(context, listen: false).fetchCompletedTasks(workerId);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Tasks',
          style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w600),
        ),
      ),
      body: Column(
        children: [
          // --- Custom Tabs Section ---
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildTabItem(0, "Accepted Task"),
                _buildTabItem(1, "In Progress"),
                _buildTabItem(2, "Completed"),
              ],
            ),
          ),
          const SizedBox(height: 10),

          // --- Task List Section ---
          Expanded(
            child: _buildTaskListByTab(),
          ),
        ],
      ),
    );
  }

  // Logic to switch between Providers based on Tab Index
  Widget _buildTaskListByTab() {
    if (_selectedTabIndex == 0) {
      return Consumer<AcceptedTaskProvider>(
        builder: (context, provider, _) => _buildList(provider.isLoading, provider.tasks, "No accepted tasks"),
      );
    } else if (_selectedTabIndex == 1) {
      return Consumer<InProgressTaskProvider>(
        builder: (context, provider, _) => _buildList(provider.isLoading, provider.tasks, "No tasks in progress"),
      );
    } else {
      return Consumer<CompleteTaskProvider>(
        builder: (context, provider, _) => _buildList(provider.isLoading, provider.tasks, "No completed tasks"),
      );
    }
  }

  // Generic List Builder
  Widget _buildList(bool isLoading, List tasks, String emptyMessage) {
    if (isLoading) {
      return const Center(child: CircularProgressIndicator(color: Color(0xFFA13C2B)));
    }
    if (tasks.isEmpty) {
      return Center(child: Text(emptyMessage));
    }
    return RefreshIndicator(
     onRefresh:   () async {
 
    await Future.delayed(Duration(seconds: 1));},
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: tasks.length,
        itemBuilder: (context, index) => _buildTaskCard(tasks[index]),
      ),
    );
  }

  // Tab Button Widget
  Widget _buildTabItem(int index, String title) {
    bool isSelected = _selectedTabIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _selectedTabIndex = index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFFFF1F0) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          title,
          style: TextStyle(
            color: isSelected ? const Color(0xFFA13C2B) : Colors.grey,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
            fontSize: 13,
          ),
        ),
      ),
    );
  }

  // Generic Task Card (Works with different models as long as property names match)
    Widget _buildTaskCard(dynamic task) {
    return GestureDetector(
      onTap: () {
        // Navigate based on the selected tab index
        if (_selectedTabIndex == 0) {
          Navigator.push(context, MaterialPageRoute(
            builder: (context) => ProjectDetailsScreen(task: task)));
        } else if (_selectedTabIndex == 1) {
          Navigator.push(context, MaterialPageRoute(
            builder: (context) => InprogresstaskDetailScreen(task: task)));
        } else {
          Navigator.push(context, MaterialPageRoute(
            builder: (context) => CompletedTaskDetailscreen(task: task)));
        }
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: colors.container_color,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  task.categoryName ?? "Category",
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Color(0xFF535E73)),
                ),
                Text(
                  "₹${task.budget}/-",
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Color(0xFF535E73)),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Image.asset(Appicons.loaction_icon, scale: 5, color: Colors.grey),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    task.location ?? "No Location",
                    style: const TextStyle(color: Colors.grey, fontSize: 13),
                  ),
                ),
              ],
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 15.0),
              child: Divider(color: Color(0xFFF0F0F0), thickness: 1.5),
            ),
            Row(
              children: [
                Expanded(
                  child: Text(
                    task.taskDescription ?? "No description available",
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Color(0xFF7D8797), fontSize: 13, height: 1.4),
                  ),
                ),
                const SizedBox(width: 10),
                const Icon(Icons.arrow_forward_ios, size: 16, color: Color(0xFF535E73)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}